<?php
    echo $_GET["email"];
?>