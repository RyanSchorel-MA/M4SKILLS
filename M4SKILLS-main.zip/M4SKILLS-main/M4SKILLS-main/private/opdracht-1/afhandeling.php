<?php
    echo "Welkom! Uw emailadres is " . $_POST["email"];
?>